import pika
import json

CLOUDAMQP_URL = "amqps://uwfmfenx:B9g5dK_K8wKzgI-NLxyafohS5fc8Vu8q@capybara.lmq.cloudamqp.com/uwfmfenx"


QUEUE_NAME = "pedidoRegistradoEvent" 

def callback(ch, method, properties, body):
    """
    Esta función se ejecuta cada vez que llega un mensaje a la cola.
    """
    try:
        mensaje = json.loads(body.decode("utf-8"))

        print("\n📩 [NUEVO MENSAJE RECIBIDO]")
        print(f"Dirección ID: {mensaje.get('direccion_cliente_id')}")
        print(f"Fecha Pedido: {mensaje.get('fecha_pedido')}")
        print(f"Total: {mensaje.get('total')}")
        print(f"Estudiante: Angela Arcos") 
        print("-" * 40)

    except Exception as e:
        print("❌ Error procesando mensaje:", str(e))

def main():
    print("🚀 Iniciando suscriptor RabbitMQ en CloudAMQP...")

    try:
        params = pika.URLParameters(CLOUDAMQP_URL)
        connection = pika.BlockingConnection(params)
        channel = connection.channel()

        channel.queue_declare(queue=QUEUE_NAME, durable=True)

        print(f"📡 Escuchando la cola: {QUEUE_NAME}")
        print("⏳ Esperando mensajes... Presiona CTRL + C para salir\n")

        channel.basic_consume(
            queue=QUEUE_NAME,
            on_message_callback=callback,
            auto_ack=True  
        )

        channel.start_consuming()

    except KeyboardInterrupt:
        print("\n🛑 Suscriptor detenido por el usuario")
    except Exception as e:
        print("❌ Error en la conexión:", str(e))

if __name__ == "__main__":
    main()