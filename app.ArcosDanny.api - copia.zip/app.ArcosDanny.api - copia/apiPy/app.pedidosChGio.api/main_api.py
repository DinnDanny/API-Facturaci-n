from fastapi import FastAPI
from fastapi.responses import HTMLResponse 
from app.api.routes import router
from app.core.database import engine, Base

app = FastAPI()
app.title = "Api service ECPedidos"
app.version = "0.0.1"


Base.metadata.create_all(bind=engine)

app.include_router(router)

@app.get("/", tags=['Home'])
def root():
    return {"message": "API EcPedidos funcionando"}


@app.get('/html', tags=['test'], response_class=HTMLResponse)
def message():
    return '<h1>Aplicaciones Distribuidas -- Apis en Python</h1>'